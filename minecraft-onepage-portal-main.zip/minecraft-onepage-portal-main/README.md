# minecraft-onepage-portal
A simple one-page dark themed Minecraft website template

Available on SpigotMC: https://www.spigotmc.org/resources/dusk-%E2%98%85-minecraft-dark-theme-website-%E2%98%85-fully-responsive.51246/
